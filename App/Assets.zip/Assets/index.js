const allLogo = {
  logo1: require('./img/logo1.png'),
  icVisibilityOn: require('./img/ic_visibility_on.png'),
  icVisibilityOff: require('./img/ic_visibility_off.png'),
  icGoogle: require('./img/ic_google.png'),
  icFacebook: require('./img/ic_facebook.png'),
  loading: require('./img/loading.gif'),

}

export { allLogo }
