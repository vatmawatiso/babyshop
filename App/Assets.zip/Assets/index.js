const allLogo = {
  logo1: require('./img/logo1.png'),
  icsearch: require('./img/ic_search.png'),
  iccart: require('./img/ic_cart.png'),
  icnav: require('./img/ic_nav.png'),
  ichome: require('./img/ic_home.png'),
  icwishlist: require('./img/ic_wishlist.png'),
  icnotification: require('./img/ic_notification.png'),
  icprofil: require('./img/ic_profil.png'),
  icVisibilityOn: require('./img/ic_visibility_on.png'),
  icVisibilityOff: require('./img/ic_visibility_off.png'),
  icGoogle: require('./img/ic_google.png'),
  icFacebook: require('./img/ic_facebook.png'),
  ichouse: require('./img/ic_house.png'),
  icworkers: require('./img/ic_workers.png'),
  icbuilder: require('./img/ic_builder.png'),
  icbrokerage: require('./img/ic_brokerage.png'),
  ichomerenovation: require('./img/ic_homerenovation.png'),
  loading: require('./img/loading.gif'),

}

export { allLogo }
